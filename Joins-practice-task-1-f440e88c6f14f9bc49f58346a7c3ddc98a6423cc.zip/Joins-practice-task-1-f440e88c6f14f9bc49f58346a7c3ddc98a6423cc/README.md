# Joins-practice-task-1
**COMPANY**: CODTECH IT SOLUTIONS
**NAME**: NAGAMANI ANANGI
**INTERN ID**:CT6WOXI
**DOMAIN**: SQL
**DURATION**: JAN 25th TO MAR 10th
**MENTOR NAME**:Neela Santhosh Kumar
**DESCRIPTION**:INNER JOIN: Only returns rows with matching values in both tables.
LEFT JOIN: Returns all rows from the left table and matched rows from the right table.
RIGHT JOIN: Returns all rows from the right table and matched rows from the left table.
FULL JOIN: Returns all rows from both tables, with NULLs for unmatched rows.
